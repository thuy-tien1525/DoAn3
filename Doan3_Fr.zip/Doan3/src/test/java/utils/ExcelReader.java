package utils;
import org.apache.poi.ss.usermodel.*;

import java.io.File;
import java.io.FileInputStream;

public class ExcelReader {

    public static String[][] readExcel(String filePath, String sheetName) {
        try (FileInputStream fis = new FileInputStream(new File(filePath))) {
            Workbook workbook = WorkbookFactory.create(fis);
            Sheet sheet = workbook.getSheet(sheetName);

            if (sheet == null) {
                throw new IllegalArgumentException("Sheet không tồn tại: " + sheetName);
            }

            int rows = sheet.getPhysicalNumberOfRows();
            int cols = sheet.getRow(0).getPhysicalNumberOfCells();

            // Giảm 1 dòng đầu tiên vì đó là tiêu đề
            String[][] data = new String[rows - 1][cols];

            for (int i = 1; i < rows; i++) {  // Bắt đầu từ dòng thứ 2 (index 1)
                Row row = sheet.getRow(i);
                for (int j = 0; j < cols; j++) {
                    Cell cell = row.getCell(j);
                    data[i - 1][j] = (cell == null) ? "" : cell.toString();  // Ghi dữ liệu vào mảng
                }
            }

            return data;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
