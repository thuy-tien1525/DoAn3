package utils;
import java.io.IOException;


public class Reports {
    private static HtmlReporter reporter;

    /**
     * Khởi tạo file báo cáo HTML.
     * @param filePath Đường dẫn lưu file báo cáo HTML
     * @throws IOException Lỗi nếu không ghi được file
     */
    public static void initReport(String filePath) throws IOException {
        if (reporter == null) {
            reporter = new HtmlReporter(filePath);
        }
    }

    /**
     * Thêm 1 dòng kết quả test vào báo cáo HTML.
     * @param testCase Tên test case
     * @param input Dữ liệu đầu vào
     * @param expected Kết quả mong đợi
     * @param actual Kết quả thực tế
     * @param result PASS hoặc FAIL
     */
    public static void addTestRow(String testCase, String input, String expected, String actual, String result) {
        try {
            if (reporter != null) {
                reporter.addRow(testCase, input, expected, actual, result);
            }
        } catch (IOException e) {
            System.out.println("Lỗi khi ghi dòng báo cáo: " + e.getMessage());
        }
    }

    /**
     * Đóng file báo cáo sau khi test kết thúc.
     */
    public static void closeReport() {
        try {
            if (reporter != null) {
                reporter.close();
                reporter = null;
            }
        } catch (IOException e) {
            System.out.println("Lỗi khi đóng báo cáo: " + e.getMessage());
        }
    }
}
