package utils;
import java.io.*;
public class HtmlReporter {
    private Writer writer;

    public HtmlReporter(String path) throws IOException {
        // ❗ Sử dụng OutputStreamWriter với UTF-8 để ghi tiếng Việt
        writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(path), "UTF-8"));
        writer.write("<html><head><meta charset='UTF-8'><title>Báo cáo kiểm thử</title></head><body>");
        writer.write("<h2>Báo cáo kết quả kiểm thử</h2>");
        writer.write("<table border='1' cellspacing='0' cellpadding='5'><tr>" +
                "<th>Test Case</th><th>Input</th><th>Expected</th><th>Actual</th><th>Result</th></tr>");
    }

    public void addRow(String testCase, String input, String expected, String actual, String result) throws IOException {
        String color = result.equalsIgnoreCase("PASS") ? "green" : "red";
        writer.write("<tr>");
        writer.write("<td>" + escapeHtml(testCase) + "</td>");
        writer.write("<td>" + escapeHtml(input) + "</td>");
        writer.write("<td>" + escapeHtml(expected) + "</td>");
        writer.write("<td>" + escapeHtml(actual) + "</td>");
        writer.write("<td style='color:" + color + "'><b>" + result + "</b></td>");
        writer.write("</tr>");
    }

    public void close() throws IOException {
        writer.write("</table></body></html>");
        writer.close();
    }

    // ✅ Escape các ký tự đặc biệt để tránh lỗi HTML
    private String escapeHtml(String text) {
        if (text == null) return "";
        return text.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }
}
