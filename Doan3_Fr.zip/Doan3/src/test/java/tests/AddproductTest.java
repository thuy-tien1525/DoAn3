package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import pages.AddproductPage;
import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class AddproductTest {
    WebDriver driver;
    AddproductPage cartPage;

    static ExtentReports extent;
    ExtentTest test;

    @BeforeSuite
    public void startReport() {
        ExtentSparkReporter htmlReporter = new ExtentSparkReporter("test-output/CartTestReport.html");
        htmlReporter.config().setDocumentTitle("Báo cáo kiểm thử giỏ hàng");
        htmlReporter.config().setReportName("Cart Functionality Test Report");

        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
        extent.setSystemInfo("Tester", "Phạm Thủy Tiên");
        extent.setSystemInfo("Environment", "Local Testing");
    }

    @BeforeClass
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        cartPage = new AddproductPage(driver);
    }

    @Test
    public void kiemThuThemSanPhamVaoGioHang() {
        test = extent.createTest("Kiểm thử thêm sản phẩm vào giỏ hàng");

        try {
            cartPage.themsanpham(); // Giả định đây là thêm 1 sản phẩm
            test.info("Thêm sản phẩm vào giỏ hàng");

            cartPage.moGioHang(); // Mở giỏ hàng
            test.info("Mở giỏ hàng để kiểm tra");

            boolean coSanPham = cartPage.kiemTraSanPhamTrongGio();
            test.info("Kiểm tra sự tồn tại của sản phẩm trong giỏ");

            Assert.assertTrue(coSanPham, "Không thấy sản phẩm trong giỏ hàng!");
            test.pass("PASS - Sản phẩm đã được thêm thành công vào giỏ.");

        } catch (Exception e) {
            test.fail("Lỗi phát sinh: " + e.getMessage());
            Assert.fail("Test thất bại do lỗi: " + e.getMessage(), e);
        }
    }

    @AfterClass
    public void teardown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @AfterSuite
    public void endReport() {
        extent.flush();
    }
}
