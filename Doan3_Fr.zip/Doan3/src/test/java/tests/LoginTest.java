package tests;

import org.testng.Assert;
import org.testng.annotations.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pages.LoginPage;
import utils.ExcelReader;

import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import java.text.Normalizer;
import java.util.regex.Pattern;

public class LoginTest {
    WebDriver driver;
    LoginPage loginPage;

    static ExtentReports extent;
    ExtentTest test;

    @BeforeSuite
    public void startReport() {
        // Khởi tạo báo cáo HTML
        ExtentSparkReporter htmlReporter = new ExtentSparkReporter("test-output/LoginTestReport.html");
        htmlReporter.config().setDocumentTitle("Báo cáo kiểm thử đăng nhập");
        htmlReporter.config().setReportName("Login Test Report");

        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
        extent.setSystemInfo("Tester", "Phạm Thủy Tiên");
        extent.setSystemInfo("Environment", "Local Testing");
    }

    @BeforeClass
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        loginPage = new LoginPage(driver);
    }

    @DataProvider(name = "loginData")
    public Object[][] loginData() {
        String filePath = "src/test/resources/Data.xlsx";
        return ExcelReader.readExcel(filePath, "Sheet1");
    }

    @Test(dataProvider = "loginData")
    public void kiemThuDangNhap(String email, String matKhau, String thongBaoMongDoi) {
        test = extent.createTest(" Kiểm thử đăng nhập với: " + email);

        try {
            loginPage.openLoginPage();
            test.info(" Mở trang đăng nhập");

            loginPage.login(email, matKhau);
            test.info("Nhập email: `" + email + "` - Mật khẩu: `" + matKhau + "`");

            String ketQuaThucTe = loginPage.layThongBao();
            test.info(" Thông báo thực tế: `" + ketQuaThucTe + "`");
            test.info(" Kết quả mong đợi: `" + thongBaoMongDoi + "`");

            String actual = normalizeText(ketQuaThucTe);
            String expected = normalizeText(thongBaoMongDoi);

            if (actual.contains(expected)) {
                test.pass(" PASS - Kết quả khớp với mong đợi.");
            } else {
                test.fail(" FAIL - Kết quả không khớp.\n ➤ Mong đợi: " + thongBaoMongDoi + "\n ➤ Thực tế: " + ketQuaThucTe);
                Assert.fail("Kết quả không khớp với mong đợi.");
            }

        } catch (Exception e) {
            test.fail(" Lỗi phát sinh: " + e.getMessage());
            Assert.fail("Lỗi trong quá trình test: " + e.getMessage(), e);
        } finally {
            driver.navigate().refresh();
        }
    }

    @AfterClass
    public void teardown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @AfterSuite
    public void endReport() {
        extent.flush();
    }

    private String normalizeText(String text) {
        if (text == null) return "";
        String normalized = Normalizer.normalize(text, Normalizer.Form.NFD);
        return Pattern.compile("\\p{InCombiningDiacriticalMarks}+")
                .matcher(normalized)
                .replaceAll("")
                .toLowerCase()
                .trim();
    }
}
