package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import pages.SearchPage;
import utils.ExcelReader;

import java.text.Normalizer;
import java.util.regex.Pattern;

public class SearchTest {
    WebDriver driver;
    SearchPage searchPage;

    static ExtentReports extent;
    ExtentTest test;

    @BeforeSuite
    public void startReport() {
        ExtentSparkReporter htmlReporter = new ExtentSparkReporter("test-output/SearchTestReport.html");
        htmlReporter.config().setDocumentTitle("Báo cáo kiểm thử tìm kiếm");
        htmlReporter.config().setReportName("Search Test Report");

        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
        extent.setSystemInfo("Tester", "Phạm Thủy Tiên");
        extent.setSystemInfo("Environment", "Local Testing");
    }

    @BeforeClass
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        searchPage = new SearchPage(driver);
    }

    @DataProvider(name = "searchData")
    public Object[][] searchData() {
        String filePath = "src/test/resources/Data.xlsx";
        String sheetName = "Sheet2";
        return ExcelReader.readExcel(filePath, sheetName);
    }

    @Test(dataProvider = "searchData")
    public void kiemThuTimKiem(String tuKhoa, String thongBaoMongDoi) {
        test = extent.createTest(" Kiểm thử tìm kiếm: `" + tuKhoa + "`");

        try {
            searchPage.openLoginPage();
            test.info(" Mở trang tìm kiếm");

            searchPage.Search(tuKhoa);
            test.info("Nhập từ khóa: `" + tuKhoa + "`");

            String ketQuaThucTe = searchPage.layThongBao();
            test.info(" Thông báo thực tế: `" + ketQuaThucTe + "`");
            test.info(" Kỳ vọng: `" + thongBaoMongDoi + "`");

            String actual = normalizeText(ketQuaThucTe);
            String expected = normalizeText(thongBaoMongDoi);

            if (actual.contains(expected)) {
                test.pass(" PASS - Kết quả đúng như mong đợi");
            } else {
                test.fail(" FAIL - Kết quả không khớp\n➤ Mong đợi: " + thongBaoMongDoi + "\n➤ Thực tế: " + ketQuaThucTe);
                Assert.fail("Kết quả không khớp.");
            }

        } catch (Exception e) {
            test.fail(" Lỗi xảy ra: " + e.getMessage());
            Assert.fail("Lỗi trong quá trình test: " + e.getMessage(), e);
        }
    }

    @AfterClass
    public void teardown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @AfterSuite
    public void endReport() {
        extent.flush(); // Xuất file báo cáo
    }

    private String normalizeText(String text) {
        if (text == null) return "";
        String normalized = Normalizer.normalize(text, Normalizer.Form.NFD);
        return Pattern.compile("\\p{InCombiningDiacriticalMarks}+")
                .matcher(normalized)
                .replaceAll("")
                .toLowerCase()
                .trim();
    }
}
