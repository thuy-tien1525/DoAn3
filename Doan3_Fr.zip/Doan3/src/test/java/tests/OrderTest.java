package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import pages.OrderPage;

import java.time.Duration;

public class OrderTest {
    WebDriver driver;
    OrderPage orderPage;

    static ExtentReports extent;
    ExtentTest test;

    @BeforeSuite
    public void startReport() {
        ExtentSparkReporter htmlReporter = new ExtentSparkReporter("test-output/OrderTestReport.html");
        htmlReporter.config().setDocumentTitle("Báo cáo đặt hàng");
        htmlReporter.config().setReportName("Order Test Report");

        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
        extent.setSystemInfo("Tester", "Phạm Thủy Tiên");
        extent.setSystemInfo("Environment", "Local Testing");
    }

    @BeforeClass
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        orderPage = new OrderPage(driver);
    }

    @Test
    public void testDatHangThanhCong() {
        test = extent.createTest(" Kiểm thử đặt hàng thành công");

        // Dữ liệu mẫu
        String email = "testuser@example.com";
        String hoTen = "Nguyễn Văn A";
        String soDienThoai = "0912345678";
        String diaChiDayDu = "Phường Trúc Bạch , Quận Ba Đình, Thành phố Hà Nội";

        try {
            orderPage.datHangThanhCong(email, hoTen, soDienThoai, diaChiDayDu);
            test.info("Đã nhập thông tin đặt hàng");

            String thongBao = orderPage.layThongBaoThanhCong();
            test.info("Thông báo nhận được: " + thongBao);

            if (thongBao.contains("Chọn phương thức thanh toán")) {
                test.pass(" Đặt hàng thành công");
            } else {
                test.fail(" Không có thông báo đặt hàng thành công. Nhận được: " + thongBao);
            }

        } catch (Exception e) {
            test.fail(" Lỗi trong quá trình đặt hàng: " + e.getMessage());
        }
    }

    @AfterClass
    public void teardown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @AfterSuite
    public void endReport() {
        extent.flush();
    }
}
