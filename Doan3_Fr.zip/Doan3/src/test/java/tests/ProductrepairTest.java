package tests;

import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;
import pages.ProductrepairPage;

public class ProductrepairTest {
    WebDriver driver;
    ProductrepairPage productPage;

    ExtentReports extent;
    ExtentTest test;

    @BeforeClass
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        productPage = new ProductrepairPage(driver);

        // Khởi tạo báo cáo
        ExtentSparkReporter htmlReporter = new ExtentSparkReporter("test-output/ProductRepairReport.html");
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
    }

    @Test
    public void testTangVaGiamSoLuong() throws InterruptedException {
        test = extent.createTest("Test Tăng và Giảm Số Lượng Sản Phẩm", "Kiểm tra thay đổi số lượng trong giỏ hàng");

        productPage.themsanpham();
        test.info("Đã thêm sản phẩm vào giỏ hàng");

        productPage.moGioHang();
        test.info("Đã mở giỏ hàng");

        // Tăng số lượng
        String[] tang = productPage.suaSoLuongSanPham(2, true);
        test.pass(" Tăng số lượng thành công: Trước = " + tang[0] + " | Sau = " + tang[1]);

        // Giảm số lượng
        String[] giam = productPage.suaSoLuongSanPham(1, false);
        test.pass(" Giảm số lượng thành công: Trước = " + giam[0] + " | Sau = " + giam[1]);
    }

    @AfterClass
    public void teardown() {
        if (driver != null) {
            driver.quit();
        }
        // Kết thúc và flush report
        extent.flush();
    }
}
