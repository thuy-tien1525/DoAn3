package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import pages.DeleteproductPage;
import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import pages.DeleteproductPage;

public class DeleteproductTest {
    WebDriver driver;
    DeleteproductPage cartPage;

    static ExtentReports extent;
    ExtentTest test;

    @BeforeSuite
    public void startReport() {
        ExtentSparkReporter htmlReporter = new ExtentSparkReporter("test-output/DeleteProductReport.html");
        htmlReporter.config().setDocumentTitle("Báo cáo kiểm thử xóa sản phẩm");
        htmlReporter.config().setReportName("Delete Product Test Report");

        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
        extent.setSystemInfo("Tester", "Tên của bạn");
        extent.setSystemInfo("Environment", "Local Testing");
    }

    @BeforeClass
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        cartPage = new DeleteproductPage(driver);
    }

    @Test
    public void testXoaSanPhamKhoiGio() {
        test = extent.createTest("Kiểm thử thêm và xóa sản phẩm trong giỏ hàng");

        try {
            cartPage.themsanpham();
            test.info(" Đã thêm sản phẩm vào giỏ");

            cartPage.moGioHang();
            test.info(" Đã mở giỏ hàng");

            boolean daThem = cartPage.kiemTraSanPhamTrongGio();
            Assert.assertTrue(daThem, " Không tìm thấy sản phẩm sau khi thêm.");
            test.pass(" Sản phẩm xuất hiện trong giỏ hàng sau khi thêm");

            cartPage.xoaSanPhamKhoiGio();
            test.info(" Đã thực hiện thao tác xóa sản phẩm");

            boolean conTrongGio = cartPage.kiemTraSanPhamTrongGio();
            Assert.assertFalse(conTrongGio, " Sản phẩm vẫn còn trong giỏ sau khi xóa.");
            test.pass(" Sản phẩm đã bị xóa thành công khỏi giỏ hàng");

        } catch (Exception e) {
            test.fail(" Lỗi khi kiểm thử xóa sản phẩm: " + e.getMessage());
            Assert.fail("Test thất bại vì lỗi ngoại lệ", e);
        }
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @AfterSuite
    public void endReport() {
        extent.flush();
    }
}
