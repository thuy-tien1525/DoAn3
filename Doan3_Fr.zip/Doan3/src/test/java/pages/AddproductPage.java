package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class AddproductPage {
    private WebDriver driver;
    private WebDriverWait wait;


    private By themvaogio = By.xpath("/html/body/main/div[1]/div/div[2]/div[1]/div[2]/div/div[3]/div[3]/button[1]");
    private By iconGioHang = By.cssSelector("body > header > div.headerContainer.bg-primary.text-white > div > div.flex-1.md\\:min-w-\\[300px\\] > div > div.relative.cart-icon.w-9.h-9.flex.flex-col.justify-center.items-center.cursor-pointer > div.cursor-pointer.hidden.md\\:block > svg");
    private By xemgiohang = By.cssSelector("body > header > div.headerContainer.bg-primary.text-white > div > div.flex-1.md\\:min-w-\\[300px\\] > div > div.relative.cart-icon.w-9.h-9.flex.flex-col.justify-center.items-center.cursor-pointer > div.minicart-content.rounded-b.hidden.md\\:block.md\\:w-\\[368px\\].md\\:z-10.text-muji_gray_800.bg-white.text.md\\:absolute.md\\:-right-2.lg\\:-right-3.md\\:top-\\[53px\\].lg\\:top-16.md\\:shadow-md.md\\:p-6 > div.flex.flex-col.gap-4.pt-4.text-center > button.inline-flex.items-center.justify-center.whitespace-nowrap.rounded-md.ring-offset-background.transition-colors.focus-visible\\:outline-none.focus-visible\\:ring-2.focus-visible\\:ring-ring.focus-visible\\:ring-offset-2.disabled\\:pointer-events-none.disabled\\:opacity-50.px-4.py-2.bg-white.border.h-\\[56px\\].hover\\:bg-white.border-muji_gray_400.text-muji_gray_800.font-bold.text-\\[15px\\]");
    private By tenSanPhamTrongGio = By.cssSelector("body > main > div.cart-page.mt-6.md\\:max-w-\\[1352px\\].min-h-\\[500px\\].mx-auto.md\\:mt-10.flex.flex-col.w-full.gap-6.md\\:gap-5 > div > div.cart-items.px-\\[15px\\].pb-6.md\\:px-0.w-full > div.flex.w-full.flex-col.gap-6.pt-4.mt-6.border-t-2.border-muji_gray_200 > div:nth-child(1) > div > div.flex.flex-col.gap-2.text-\\[13px\\].w-full > a > p");  // Cần điều chỉnh đúng selector nếu khác


    public AddproductPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void themsanpham(){
        driver.get("https://www.muji.com.vn/vn/product/muji-steel-divider-board-4550182603071");
        wait.until(ExpectedConditions.elementToBeClickable(themvaogio)).click();
    }

    public void moGioHang() throws InterruptedException {
        wait.until(ExpectedConditions.elementToBeClickable(iconGioHang)).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(xemgiohang));
        wait.until(ExpectedConditions.elementToBeClickable(xemgiohang)).click();

        Thread.sleep(5000);

    }

    public boolean kiemTraSanPhamTrongGio() {
        try {
            WebElement tenSanPham = wait.until(ExpectedConditions.visibilityOfElementLocated(tenSanPhamTrongGio));
            String ten = tenSanPham.getText().trim();
            System.out.println("Sản phẩm trong giỏ: " + ten);
            return !ten.isEmpty();
        } catch (TimeoutException e) {
            System.out.println("Không load được tên sản phẩm trong thời gian chờ: " + e.getMessage());
            return false;
        } catch (Exception e) {
            System.out.println("Lỗi khác khi kiểm tra giỏ hàng: " + e.getMessage());
            return false;
        }
    }

}
