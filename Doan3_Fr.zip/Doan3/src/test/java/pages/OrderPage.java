
package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class OrderPage {
    private WebDriver driver;
    private WebDriverWait wait;

    private By btnMuaHang = By.xpath("/html/body/main/div[1]/div[2]/div[2]/div[2]/div/div[1]/div[1]/div[2]/button");
    private By iconGioHang = By.xpath("//div[@class='cursor-pointer hidden md:block']//*[name()='svg']");
    private By btnThanhToan = By.xpath("//button[normalize-space()='Thanh toán']");
    private By btnKhongDangKy = By.xpath("//button[contains(text(),'Đặt hàng không cần đăng ký')]");
    private By txtEmail = By.name("email");
    private By txtHoTen = By.name("full_name");
    private By txtSoDienThoai = By.name("telephone");
    private By dropdownThanhPho = By.cssSelector("button[id=':r3:-form-item'] svg");
    private By dropdownQuan = By.cssSelector("button[id=':r5:-form-item'] svg");
    private By dropdownPhuong = By.cssSelector("button[id=':r7:-form-item'] svg");
    private By txtDiaChiChiTiet = By.name("street");
    private By btnXacNhanDiaChi = By.xpath("//button[contains(text(),'XÁC NHẬN ĐỊA CHỈ')]");
    private By radioPhuongThucThanhToan = By.cssSelector("body > main > div.checkout-page.mt-10.md\\:mt-\\[53px\\].text-left.w-full.flex.flex-col.gap-10.md\\:flex-row.md\\:flex-nowrap.justify-center.min-h-screen.px-\\[15px\\].md\\:gap-6.lg\\:gap-10.xl\\:gap-\\[128px\\].md\\:px-4.lg\\:px-16.md\\:mb-\\[60px\\].max-w-screen-lg > div.right-columns.w-full.md\\:w-\\[50\\%\\].flex.flex-col.gap-10.xl\\:w-\\[496px\\] > div.payment-method.px-\\[15px\\].py-6.md\\:px-6.md\\:py-8 > div > div:nth-child(3) > p > span");

    private By ttthanhtoan = By.xpath("//button[normalize-space()='Thanh toán']");
    // ==================== Thông Báo Thành Công ====================
    private By thongBaoThanhCong = By.cssSelector(".h2.text-center.main-title-mobile.mb24");


    public OrderPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void datHangThanhCong(String email, String hoTen, String sdt, String diaChiDayDu) throws InterruptedException {
        // 1. Mở trang sản phẩm
        driver.get("https://www.muji.com.vn/vn/product/muji-steel-divider-board-4550182603071");
        WebElement btn = driver.findElement(By.xpath("/html/body/main/div[1]/div/div[2]/div[1]/div[2]/div/div[3]/div[3]/button[2]"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);

        // 3. Nhấn “Thanh toán” trong giỏ hàng
        wait.until(ExpectedConditions.elementToBeClickable(iconGioHang)).click();
        wait.until(ExpectedConditions.elementToBeClickable(btnThanhToan)).click();

        // 4. Nhấn “Đặt hàng không cần đăng ký”
        wait.until(ExpectedConditions.elementToBeClickable(btnKhongDangKy)).click();
        driver.get("https://www.muji.com.vn/vn/checkout");

        // 5. Nhập thông tin khách hàng
        wait.until(ExpectedConditions.visibilityOfElementLocated(txtEmail)).sendKeys(email);
        driver.findElement(txtHoTen).sendKeys(hoTen);
        driver.findElement(txtSoDienThoai).sendKeys(sdt);

        // 6. Chọn tỉnh, huyện, xã
        String[] parts = diaChiDayDu.split(",");
        if (parts.length < 3) throw new IllegalArgumentException("Địa chỉ không hợp lệ");

        chonDropdown(dropdownThanhPho, parts[2].trim());
        chonDropdown(dropdownQuan, parts[1].trim());
        chonDropdown(dropdownPhuong, parts[0].trim());

        // 7. Nhập địa chỉ cụ thể
        driver.findElement(txtDiaChiChiTiet).sendKeys(diaChiDayDu);
        wait.until(ExpectedConditions.elementToBeClickable(btnXacNhanDiaChi)).click();

        // 8. Chọn phương thức thanh toán và xác nhận
        wait.until(ExpectedConditions.elementToBeClickable(radioPhuongThucThanhToan)).click();

        WebElement button = wait.until(ExpectedConditions.elementToBeClickable(ttthanhtoan));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({ block: 'center' });", button);
        button.click();

    }

    private void chonDropdown(By dropdownIcon, String optionText) {
        wait.until(ExpectedConditions.elementToBeClickable(dropdownIcon)).click();
        By option = By.xpath("//div[@role='option' and contains(normalize-space(.), '" + optionText + "')]");
        WebElement optionElement = wait.until(ExpectedConditions.elementToBeClickable(option));
        optionElement.click();

        // Cuộn xuống sau khi chọn để đảm bảo dropdown tiếp theo hiển thị
        ((JavascriptExecutor) driver).executeScript("window.scrollBy(0, 300);");
    }

    public String layThongBaoThanhCong() {
        try {
            WebElement message = wait.until(ExpectedConditions.visibilityOfElementLocated(thongBaoThanhCong));
            return message.getText().trim();
        } catch (TimeoutException e) {
            return "Không tìm thấy thông báo thành công.";
        }
    }

}
