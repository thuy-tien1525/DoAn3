package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;

import java.time.Duration;

public class LoginPage {
    private WebDriver driver;
    private WebDriverWait wait;

    // Locators
    private By btnDangNhapTrangChu = By.xpath("//a[contains(text(),'Đăng nhập')]");
    private By txtEmail = By.id("email");
    private By txtMatKhau = By.id("password");
    private By btnDangNhap = By.xpath("//button[contains(text(),'Đăng nhập')]");
    private By loiemail = By.xpath("/html/body/main/div[1]/div/div/div/div[2]/form/div[1]/p");
    private By loimatkhau = By.xpath("/html/body/main/div[1]/div/div/div/div[2]/form/div[2]/div[1]/p");
    private By thanhcong = By.xpath("/html/body/header/div[2]/div/div[2]/div[2]/span[2]");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void openLoginPage() {
        driver.get("https://www.muji.com.vn/vn");

        wait.until(ExpectedConditions.elementToBeClickable(btnDangNhapTrangChu)).click();
    }

    public void login(String email, String password) {
        WebElement emailField = wait.until(ExpectedConditions.visibilityOfElementLocated(txtEmail));
        WebElement passwordField = wait.until(ExpectedConditions.visibilityOfElementLocated(txtMatKhau));
        WebElement dangNhapButton = wait.until(ExpectedConditions.elementToBeClickable(btnDangNhap));

        emailField.clear();
        emailField.sendKeys(email);

        passwordField.clear();
        passwordField.sendKeys(password);

        dangNhapButton.click();
    }

    public String layThongBao() {
        try {
            WebElement thongBaoEmail = driver.findElement(loiemail);
            if (thongBaoEmail.isDisplayed()) {
                return thongBaoEmail.getText().trim();
            }
        } catch (NoSuchElementException ignored) {}

        try {
            WebElement thongBaoMatKhau = driver.findElement(loimatkhau);
            if (thongBaoMatKhau.isDisplayed()) {
                return thongBaoMatKhau.getText().trim();
            }
        } catch (NoSuchElementException ignored) {}

        try {

            wait.until(ExpectedConditions.urlToBe("https://www.muji.com.vn/vn"));


            WebElement tenNguoiDung = wait.until(ExpectedConditions.visibilityOfElementLocated(thanhcong));
            if (tenNguoiDung.isDisplayed()) {
                return tenNguoiDung.getText().trim();
            }
        } catch (Exception ignored) {}

        return "";
    }

}
