package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class SearchPage {
    private WebDriver driver;
    private WebDriverWait wait;

    // Locators
    private By searchbox = By.xpath("//input[@id='search']");
    private By ketqua = By.xpath("//div[contains(@class, 'total-product')]");
    private By ketqua2 = By.xpath("//*[contains(@class, 'total-product')]");

    public SearchPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void openLoginPage() {
        driver.get("https://www.muji.com.vn/vn");

    }

    public void Search(String tukhoa) throws InterruptedException {
        WebElement tukhoaField = wait.until(ExpectedConditions.visibilityOfElementLocated(searchbox));

        tukhoaField.clear();
        tukhoaField.sendKeys(tukhoa);
        tukhoaField.sendKeys(Keys.ENTER);

        Thread.sleep(15000);
    }

    public String layThongBao() {
        By[] locators = { ketqua, ketqua2 };
        for (By locator : locators) {
            try {
                WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(locator));
                String text = element.getText().trim();
                if (!text.isEmpty()) return text;
            } catch (Exception ignored) {}
        }
        return "Không tìm thấy kết quả phù hợp.";
    }

}
